# Examples of arithmetic operations in RStudio


library(abind)
install.packages("ada")
A = 15+23
A
b = 45-25
b
25/5

5*25

blibrary(ada)
A = 15+23 # addition

45-36 # Substraction

25/7 # Division

45*8 # multiplication
5^3
5^3  exponential

5**3 # exponential

x = 5 # assigning value 5 to x
y <- 5 # assigning value 5 to x
x = 10.65
x
class(x)
y = as.integer(4)
y  
class(y)
a=as.integer(4.98)
class(a)

as.integer(5.12)

w=as.character(5.98)
w
class(w)

fname="VINAYAK";lname="GURANNANAVAR"
paste(fname,lname)

'''R functions are invoked by its name, then followed by the parenthesis,
and zero or more arguments. The following command combines five
numeric values into a vector.
'''

z = c(1,2,3,4,5)
z
q = c(1,5,8,9,7,9)
q

# Package installation

  # Sometimes we need additional functionality beyond those offered by the core R library.
  # In order to install an extension package, you should invoke the install.
     # packages function at the prompt and follow the instruction.

install.packages("ada")

library(ada)
library(acepack)

# or via package option 

# Help function

help(c)

help("abind")
# Or
??c


help(ts,try.all.packages = TRUE) # The function try.all.packages allows searching all packages.

?c

# data types

'''In analysis of statistical data we use different types of data. For
manipulating such data, R supports following data types
- logical : It is a Boolean type data whose value can be TRUE or FALSE.
- numeric : It can be real or integer.
- complex : It consists of real and imaginary numbers.
'''
x = 1  # sample value
y = 2  # sample value

z = x>y # is x greater than y
z  # prints the logical value 
# [1] FALSE

class(z) # print the class name of z
# [1] "logical"

### Numeric 
'''Decimal values are called numeric in R.
• It is the default computational data type.
• If we assign a decimal value to a variable x as follows, x will be of
numeric type.
'''
x = 10.65 # assigning a decimal value to x
x
# [1] 10.65

class(x)
# [1] "numeric"


### Integer

'''In order to create an integer variable in R, we need invoke
the as.integer function. We can be assured that y is indeed an integer
by applying the is.integer function.
'''
y = as.integer(4.2)
y
class(y)
is.integer(y)
# [1] TRUE

# we can coerce a numeric value into an integer with the same as.integer function

z = as.integer(4.76)
z
# [1] 4

### complex numbers

z = 1+5i # creates a complex number
z
# [1] 1+5i
class(z)
# [1] "complex"

### Character

y = "James"
Z = "302"
ZZ = as.character("James")

'''A character object is used to represent string values in R.
We convert objects into character values with
the as.character() function:
'''
x = "name"
y = as.character(4.2)
y
class(x)

# Two character values can be concatenated with the paste function.
title = " Mr."
name = "Mohan "
paste(title,name)

c("title","name")

# [1] " Mr. Mohan "

### vectors
'''
• R operates on named data structures. The simplest such structure is
numeric vector.
• Numeric vector is a single entity consisting of an ordered collection of
numbers.
• To create a vector named x containing 5 numbers 2,5,8,1,35 use
following command
'''
x = c(2,5,8,1,35)
y = c("a","b")

c(x,y)
# This is assignment using function c(). Assignment can also be made by using assign function.
assign("y", c(2,5,8,1,35))
y
# A vector can contain character strings.
g = c("John","albert")
g

# the number of members in a vector is given by the length function.

length(c("John","albert"))

# Combining vectors
'''
• Vectors can be combined via the function c.
• For example, the following two vectors n and s are combined into a
new vector containing elements from both vectors.
'''

n = c(2,3,5)
s = c("aa","bb","cc","dd","ee")
c(n,s)
# [1] "2"  "3"  "5"  "aa" "bb" "cc" "dd" "ee"

#### Vector Arithmetic
'''
• Arithmetic operations of vectors are performed member-bymember,
i.e., member wise.
• For example, suppose we have two vectors a and b.
'''
a = c(1,3,5,7)
b = c(1,2,4,8)

# Then, if we multiply a by 5, we would get a vector with each of its members multiplied by 5.

5*a
a*5
# [1]  5 15 25 35

# And if we add a and b together, the sum would be a vector whose
   # members are the sum of the corresponding members from a and b.
a+b
# [1]  2  5  9 15

a = c(1,3,5,7)
b = c(1,2,4)
a+b

a = c(1,3,5,7,2,9)
b = c(1,2,4)
a+b
# [1] 2 5 9 8
'''Warning message:
  In a + b : longer object length is not a multiple of shorter object length '''

#### Recycling Rule
'''
If two vectors are of unequal length, the shorter one will be recycled in
order to match the longer vector. For example, the following
vectors u and v have different lengths, and their sum is computed by
recycling values of the shorter vector u.
'''
u = c(10,20,30)
v = seq(1,9,1)
# v = seq(1,9,.5)
u+v
# [1] 11 22 33 14 25 36 17 28 39


### Vector Index
'''
• We retrieve values in a vector by declaring an index inside a single
square bracket "[]" operator.
• For example, the following shows how to retrieve a vector member.
'''
s = c("aa","bb","cc","dd","ee")
s
s[3]
s[-3]
# [1] "cc"

# Negative Index
'''
If the index is negative, it would strip the member whose position has
the same absolute value as the negative index. For example, the
following creates a vector slice with the third member removed.
'''
s[-3]
# [1] "aa" "bb" "dd" "ee"

# Out-of-Range Index
 # If an index is out-of-range, a missing value will be reported via the symbol NA.
s[10]
# [1] NA

### Numeric Index Vector
'''
• A new vector can be sliced from a given vector with a numeric index
vector, which consists of member positions of the original vector to be
retrieved.
• Here it shows how to retrieve a vector slice containing the second and
third 􀅵e􀅵􀄏ers of a give􀅶 ve􀄐tor􀍛s.
'''
s = c("aa","bb","cc","dd","ee")
s[c(2,3)]
# [1] "bb" "cc"

## Duplicate Indexes
s[c(2,3,3)]
# [1] "bb" "cc" "cc"

## Out-of-Order Indexes
s[c(2,1,3)]
# [1] "bb" "aa" "cc"

### Range Index
s[2:4]
# [1] "bb" "cc" "dd"



### Named Vector Members

'''
• We can assign names to vector members.
• For example, the following variable v is a character string vector with
two members.
'''
v = c("Mary","sue")
v
# [1] "Mary" "sue"


## We now name the first member as First, and the second as Last.
names(v) = c( "first","last")
v
'''
 first   last 
"Mary"  "sue"
'''
# Then we can retrieve the first member by its name.

v [1]
v["first"]

'''
 first 
"Mary" 
'''

# Furthermore, we can reverse the order with a character string index vector.

v[c(1,2)]
v[c("Last","first")]
'''
last  first 
 "sue" "Mary"
'''

##### Matrix
'''
A matrix is a collection of data elements arranged in a twodimensional
rectangular layout. The following is an example of a matrix
with 2 rows and 3 columns.

    2 4 3
A = 
    1 5 7

We reproduce a memory representation of the matrix in R with
the matrix function.
'''
# The data elements must be of the same basic type.

A = matrix(
  c(2,4,3,1,5,7),
  nrow = 2 ,
  ncol = 3 ,
  byrow = TRUE)

A

B = matrix(
  c(2,4,3,1,5,7),
  nrow = 2 ,
  ncol = 3 )7
b
??matrix
'''
     [,1] [,2] [,3]
[1,]    2    4    3
[2,]    1    5    7
'''
# An element at the mth row, nth column of A can be accessed by the expression A[m, n]
A[2,3] # the element at 2nd row , 3rd column
# [1] 7

# The entire mth row A can be extracted as A[m, ].
A[2,] # the 2nd row
# [1] 1 5 7

# Similarly, the entire nth column A can be extracted as A[ ,n].
A[,3] # the third column

# We can also extract more than one rows or columns at a time.
A[,c(2,3)] # the first and third column

'''
     [,1] [,2]
[1,]    4    3
[2,]    5    7
'''

# If we assign names to the rows and columns of the matrix, than we can access the elements by names.

dimnames(A)= list(
  c("row1","row2"),             # row name
  c("X", "Y", "Z"))    # column name

A

'''
     col1 col2 col3
row1    2    4    3
row2    1    5    7
'''
A["row2","Z"] # element at 2nd row , 3rd column
# [1] 7


### Matrix Construction
'''
• There are various ways to construct a matrix. When we construct a
matrix directly with data elements, the matrix content is filled along
the column orientation by default.
• For example, in the following code snippet, the content of B is filled
along the columns consecutively.
'''
B = matrix(
  c(2,4,3,1,5,7),
  nrow = 3 , # 3 rows
  ncol =2)   # 2 column

B

'''
     [,1] [,2]
[1,]    2    1
[2,]    4    5
[3,]    3    7
'''
### Matrix Transpose
# We construct the transpose of a matrix by interchanging its columns and rows with the function t .
t(B) # transpose of B
'''
     [,1] [,2] [,3]
[1,]    2    4    3
[2,]    1    5    7
'''
### Combining Matrices

''' The columns of two matrices having the same number of rows can be
combined into a larger matrix. For example, suppose we have another
matrix C also with 3 rows. '''

C = matrix(
  c(7,4,2),
  nrow = 3 , # 3 rows 
  ncol = 1)  # 1 column
C
''' 
#
     [,1]
[1,]    7
[2,]    4
[3,]    2
'''
# we can combine the column of B abd C with cbind
cbind(B,C)
'''
#
     [,1] [,2] [,3]
[1,]    2    1    7
[2,]    4    5    4
[3,]    3    7    2
'''
# Similarly, we can combine the rows of two matrices if they have the same number of columns with the rbind function.
D = matrix(
  c(6,2),
  nrow = 1,
  ncol = 2)

D
B
'''
#
     [,1] [,2]
[1,]    6    2
'''
rbind(B,D)
'''
# 
     [,1] [,2]
[1,]    2    1
[2,]    4    5
[3,]    3    7
[4,]    6    2

'''
### Deconstruction
'''We can deconstruct a matrix by applying the c function, which
combines all column vectors into one '''

c(B)
# [1] 2 4 3 1 5 7


###############################################
# The Workspace
'''
IMPORTANT NOTE FOR WINDOWS USERS:
• R gets confused if you use a path in your code like
c:\mydocuments\myfile.txt

• This is because R sees "\" as an escape character. Instead, use
c:/mydocuments/myfile.txt
'''

getwd() # prints the current working directory
# [1] "D:/IMS/IMS_R_Script"

ls() # list the object in current work space

setwd(mydirectory) # change to my directory

history() # displays last 25 commands 
history(max.show = Inf) # displays all previous commands

savehistory( file = "myfile") # default is ".Rhistory"

loadhistory(file = "myfile") # default is ".Rhistory"

#################################################
# Data frame
'''
A data frame is used for storing data tables. It is a list of vectors of
equal length.
Example :
Following are the height (in cms) and weight (in kgs) of 10 boys.
Prepare a data frame of height and weight.
'''
height = c(137,140,165,156,172)
weight = c(45,51,59,54,63)
name = c("X","Y","Z","AA","BB")
data.frame(name,height,weight)

'''
#
  height weight
1    137     45
2    140     51
3    165     59
4    156     54
5    172     63
'''

######Importing data
# Importing data into R is fairly simple. Comma Delimited File (.CSV extension)

mydata <- read.csv("D/abc/housing.csv", header = "TRUE")

# text file ( .txt extension)
mydata <- read.table(""D/abc/housing.txt", header = TRUE)

##############################################
##### From Excel (.xlsx Extension)
'''
• One of the best ways to read an Excel file is to export it to a comma
delimited file and import it using the method above.
• Alternatively you can use the xlsx package to access Excel files. The
first row should contain variable/column names.
• read in the first worksheet from the workbook myexcel.xlsx
• first row contains variable names

'''

install.packages("xlsx")
library(xlsx)

mydata1 <- read.xlsx("C:/myexcel.xlsx",1) # first row contains variable names

# read in the worksheet named mysheet
mydata1 <- read.xlsx("C:/myexcel.xlsx",sheetname = "mysheet") 


# From SAS

'''
Save SAS dataset in trasport format
libname out xport 'c:/mydata.xpt';
                     data out.mydata;
                     set sasuser.mydata;
                     run;
'''

# in R

library(Hmisc)
mydata <- sasexport.get("c:/mydata.xpt")
# character variables are converted to R factors


###### Sorting Data
'''
• To sort a data frame in R, use the order( ) function.
• By default, sorting is ASCENDING. Prepend the sorting variable by a
                     minus sign to indicate DESCENDING order.
                     Here are some examples.
                     Sorting examples using the mtcars dataset

'''
mtcars = mtcars
View(mtcars)
attach(mtcars)
names(mtcars)
# sort by mpg
newdata <- mtcars[order(mtcars$mpg),]
newdata <- mtcars[order(-mtcars$mpg),]

attach(mtcars)
# sort by mpg and cyl
newdata <- mtcars[order(mpg),]
newdata <- mtcars[order(mpg,cyl),]


#sort by mpg (ascending) and cyl (descending)
newdata <- mtcars[order(mpg,-cyl),]

detach(mtcars)

# renaming a variable

# install.packages("reshape")

library(reshape)
mydata= rename(mydata, c(price = "cost"))      xit R
q() # exit R


2+3

getwd()
setwd( "D/try/ABC")


ls()
history()


data(faithful)
duration=faithful$eruption
range(duration)
breaks=seq(1.5,5.5,0.5)
breaks
duration.cut=cut(duration,breaks,right=FALSE)
duration.cut
duration.freq=cbind(table(duration.cut))
duration.freq


x=seq(200,1200,200)
x
width=200
frequency=c(6,16,24,20,10,4)
lb=x-width/2
ub=x+width/2
brks=c(lb[1],ub)
brks
y=rep(x,frequency)
hist(y,breaks=brks,xlab="monthlyhouserent",  ylab="no.of families",main="Histogram")


x=seq(200,1200,200)
x
frequency=c(6,16,24,20,10,4)
x1=c(0,x,1400)
f1=c(0,frequency,0)
plot(x1,f1,"b",xlab="monthly rent",ylab="no.of families",main="POLYGON")



vinayak

data(faithful)

xbar=9900
mu0=10000
sigma=120
                     
n=30
z=(xbar-mu0)/(sigma/sqrt(n))
z

alpha=0.05
z.alpha=qnorm(1-alpha)
-z.aplha
