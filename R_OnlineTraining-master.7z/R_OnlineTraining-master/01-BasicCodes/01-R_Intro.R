# to execute -> ctrl + enter
a <- 12
b <- 14
c <- a + b
print(c)
