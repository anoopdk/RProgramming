#Vectors -> It contains elements only of same Type
x_1 <- 1:10

x_2 <-  c(1:10)

x_3 <- c(1,2,3,4,5,'hello', 'R Programming',10.5)

y <- 2:-2

y_1 <- seq(1,10)
y_2 <- seq(1,10,by=0.2)

y_3 <- seq(from=1,to=20)

x <- 1:0.5:10
