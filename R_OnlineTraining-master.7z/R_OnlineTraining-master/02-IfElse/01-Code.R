age <- 20

if(age > 18) {
  print("You can drive")
}else {
  print("You cannot drive")
}