a <- 16

ifelse(a %% 2 == 0, 'Even', 'Odd')