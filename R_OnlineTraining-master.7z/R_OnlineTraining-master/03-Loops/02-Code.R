a <- 10
while (a < 20) {
  print(a)
  redisIncr(3)
}