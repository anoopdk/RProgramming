add <- function(x,y) {
  #x <- 12
  #y <- 13
  z <- x + y
  print(z)
}

add(12,14)
