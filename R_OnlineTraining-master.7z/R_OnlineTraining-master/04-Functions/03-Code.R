temp_conv <- function(c) {
  t = 9/5 * c + 32
  return(t)
}

temp <- temp_conv(34.5)
