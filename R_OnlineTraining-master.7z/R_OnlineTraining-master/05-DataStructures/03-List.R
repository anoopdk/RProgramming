list_1 <- list(101,102,103,104,'Ram','Shyam','Mohan','Gopal')

id <- c(101,102,103,104,105)
names <- c('Ram','Shyam','Aman','Mohan','Gopal')
company <- c('HCL','TCS','IBM','INFY',NA)

list_2 <- list(emp_id = id, emp_names = names, emp_comp = company)
