fac <- factor(c('male','female','male','male','female','female','male'))

company <- factor(c('HCL','TCS','IBM','INFY',NA,'HCL','IBM','HCL'))

