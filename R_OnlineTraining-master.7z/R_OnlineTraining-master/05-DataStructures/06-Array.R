# Array

arr <- array(1:10)

vec_1 <- 1:10
vec_2 <- 11:20

arr_2 <- array(c(vec_1, vec_2), dim = c(8,9))

arr_2 <- array(c(vec_1, vec_2), dim = c(5,5,2))
